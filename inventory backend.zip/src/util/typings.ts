
export interface IBusiness {
	name: string;
}

export interface IOrder {
	amount: number;
	date: string;
	status: string;
}